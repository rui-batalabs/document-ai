import userDataFunctions from './users.js';
import tokenFunctions from './tokens.js';

export const userData = userDataFunctions;
export const tokenData = tokenFunctions;